<?php

class PxlButtonMore_Widget extends Pxltheme_Core_Widget_Base{
    protected $name = 'pxl_button_more';
    protected $title = 'PXL Button More';
    protected $icon = 'eicon-editor-external-link';
    protected $categories = array( 'pxltheme-core' );
    protected $params = '{"sections":[{"name":"source_section","label":"Source Settings","tab":"content","controls":[{"name":"style","label":"Style","type":"select","default":"style-default","options":{"style-default":"Default"}},{"name":"text","label":"Button Text","type":"text","default":"Read More","placeholder":"Read More"},{"name":"button_url_type","label":"Link Type","type":"select","options":{"url":"URL","page":"Existing Page"},"default":"url"},{"name":"link","label":"Link","type":"url","placeholder":"https:\/\/your-link.com","condition":{"button_url_type":"url"},"default":{"url":"#"}},{"name":"page_link","label":"Existing Page","type":"select2","options":{"5678":"Home style 5","5673":"Home style 4","5573":"test","5458":"Home style 3","5407":"test","5268":"Blog Grid 3","4699":"Blog","2988":"Portfolio Grid 3","2729":"Portfolio Grid 2","1758":"Home style 1","1069":"Home style 2","1054":"Contact Me","750":"Pricing Plan","667":"My Services","225":"Portfolio Grid","171":"Blog Grid 2","125":"Blog Grid 1","13":"Wishlist","11":"My account","10":"Checkout","9":"Cart","8":"Shop"},"condition":{"button_url_type":"page"},"multiple":false,"label_block":true},{"name":"text_color","label":"Color","type":"color","selectors":{"{{WRAPPER}} .pxl-button-more .btn-more":"color: {{VALUE}};"}},{"name":"text_color_hover","label":"Color Hover","type":"color","selectors":{"{{WRAPPER}} .pxl-button-more .btn-more:hover":"color: {{VALUE}};"}}]}]}';
    protected $styles = array(  );
    protected $scripts = array(  );
}