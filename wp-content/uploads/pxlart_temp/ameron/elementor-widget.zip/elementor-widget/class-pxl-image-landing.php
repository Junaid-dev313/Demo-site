<?php

class PxlImageLanding_Widget extends Pxltheme_Core_Widget_Base{
    protected $name = 'pxl_image_landing';
    protected $title = 'PXL Image Landing';
    protected $icon = 'eicon-image';
    protected $categories = array( 'pxltheme-core' );
    protected $params = '{"sections":[{"name":"layout_section","label":"Layout","tab":"layout","controls":[{"name":"layout","label":"Layout","type":"layoutcontrol","default":"1","options":{"1":{"label":"Layout 1","image":"http:\/\/localhost:8888\/ameron\/wp-content\/themes\/ameron\/elements\/assets\/layout-image\/pxl_image_landing-1.jpg"}}}]},{"name":"content_section","label":"Content","tab":"content","controls":[{"name":"selected_image","label":"Image","type":"media"},{"name":"title_text","label":"Title Text","type":"text","default":"Homepage"},{"name":"link_type","label":"Link Type","type":"select","options":{"url":"URL","page":"Existing Page"},"default":"url"},{"name":"link","label":"Link","type":"url","placeholder":"https:\/\/your-link.com","condition":{"link_type":"url"},"default":{"url":"#"}},{"name":"page_link","label":"Existing Page","type":"select2","options":{"5678":"Home style 5","5673":"Home style 4","5573":"test","5458":"Home style 3","5407":"test","5268":"Blog Grid 3","4699":"Blog","2988":"Portfolio Grid 3","2729":"Portfolio Grid 2","1758":"Home style 1","1069":"Home style 2","1054":"Contact Me","750":"Pricing Plan","667":"My Services","225":"Portfolio Grid","171":"Blog Grid 2","125":"Blog Grid 1","13":"Wishlist","11":"My account","10":"Checkout","9":"Cart","8":"Shop"},"condition":{"link_type":"page"},"multiple":false,"label_block":true}]}]}';
    protected $styles = array(  );
    protected $scripts = array(  );
}